Beschreibung der Dateien:

Auf der Diskette befinden sich Dateien, die zu zwei verschiedenen Rexx-Projekten geh�ren:

Verzeichnis ABKUERZ:
    ABKUERZ.FRX		FleetStreet-Rexx-Skript, da� aus einer Messages die Abk�rzungen
				extrahiert und diese als Klartext an das Ende der Message anf�gt.
    ABKUERZ.LST		Diese Liste geh�rt zu ABKUERZ.FRX. Hierbei handelt es sich um 
				eine ASCII-Tabelle aller K�rzel, die "ABKUERZ" erkennt.
				Eine �bersetzung bzw. Erweiterung ist jederzeit erw�nscht!

Verzeichnis BIGFONT:
    BIGFONT.FRX		FleetStreet-Rexx-Skript, da� in eine Messages �berschriften einf�gt.
    BIGFONT.CMD		Rexx-Skript mit der Funktionalit�t von BIGFONT.FRX. Ausgabemedium
				ist entweder der Bildschirm oder eine Datei.
				Dieses Skript kann besonders gut zum Testen neuer Fonts und zur Er-
				zeugung von �berschriften in ASCII-Dateien verwendet werden.
    GENFONT.CMD		Skript zur Unterst�tzung der Generierung bzw Erweiterung neuer Fonts

    FANLIGHT.FFT		Beispielfonts f�r "BIGFONT"
    FANNORM.FFT
    STANDARD.FFT

    Bemerkung: "BIGFONT.FRX" ben�tigt einen "MONITOR" um arbeiten zu k�nnen!

Installation:	Kopieren aller Dateien in das FleetStreet-Unterverzeichnis ".\SCRIPTS".
		Bei der Wahl eines anderen Zielortes m�ssen die Pfade in den beiden "*.FRX"
		Skripten angepa�t werden!

Die Skripte ("*.FRX") funktionieren mit FleetStreet 0.96wb oder einer neueren Version